window.calculator = new CalcController();
